import { StackHeaderMenuElementIOS, StackHeaderMenuIOS } from './ios/StackHeaderMenu.ios.types';
export declare function findMenuElementByIdInMenus(menus: StackHeaderMenuIOS[], id: string): StackHeaderMenuElementIOS | null;
export declare function findMenuElementById(menu: StackHeaderMenuElementIOS, id: string): StackHeaderMenuElementIOS | null;
export declare function validateMenuCallbacks(menu: StackHeaderMenuIOS): void;
//# sourceMappingURL=utils.d.ts.map