/**
 * EXPERIMENTAL API, MIGHT CHANGE W/O ANY NOTICE
 */
declare const SplitScreen: {
    Column: () => null;
    Stack: () => null;
    Screen: () => null;
    Inspector: () => null;
};
export default SplitScreen;
//# sourceMappingURL=SplitScreen.web.d.ts.map